public class Main {
    // 1 Напишите метод, который принимает три строки и строку-разделитель.
    // Метод возвращает единую строку, состоящую из исходных строк, разделённых строкой-разделителем.
    // Например, на входе "один", "два", "три", "|". На выходе: "один|два|три"
    // 2 задание  Напишите метод, который выводит в консоль первый символ переданной в него строки.
    public static void main(String[] args) {
        String s = haha("stroka 1", "stroka 2", "stroka 3", "|");
        System.out.println(s);
        String homework = "Iam Denis";
        haha1(homework);
    }


    public static final String haha(String s1, String s2, String s3, String dilimeter4) {
        return s1 + dilimeter4 + s2 + dilimeter4 + s3;

    }

    public static void haha1(String homework){
        System.out.println(homework.charAt(0));
        

    }


}
